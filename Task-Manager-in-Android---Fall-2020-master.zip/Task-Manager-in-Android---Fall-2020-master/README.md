# TaskManger
Task Manager Application for Android devices 

Will have Details and Services tabs 
these tabs will have services listed and the details and associated with them 
